package com.example.banking_app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.List;

public class TransactionActivity extends Activity {

    private TextView transactionText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);

        transactionText = findViewById(R.id.transaction_text);
        showTransactionHistory();
    }

    private void showTransactionHistory() {
        List<Transaction> transactions = TransactionHistory.getTransactionHistory(this);
        int numTransactionsToShow = Math.min(transactions.size(), 6);

        StringBuilder sb = new StringBuilder();
        for (int i = transactions.size() - numTransactionsToShow; i < transactions.size(); i++) {
            Transaction transaction = transactions.get(i);
            String formattedDate = DateFormat.getDateTimeInstance().format(transaction.getTimestamp()); // Format the Date object as a string
            sb.append(formattedDate)
                    .append(" - ")
                    .append(transaction.getTransactionType())
                    .append(" (Amount: $")
                    .append(transaction.getAmount())
                    .append(")\n\n");
        }

        transactionText.setText(sb.toString());
    }

    public void onBackButtonClicked(View view) {
        finish();
    }
}
