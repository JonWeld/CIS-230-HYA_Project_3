package com.example.banking_app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MenuActivity extends Activity {

    private int currentBalance = 0;

    private TextView balanceTextView;
    private Button depositButton;
    private Button withdrawButton;
    private Button transferButton;
    private Button receiptButton;
    private Button payBillsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        TextView menuText = findViewById(R.id.menu_text);
        depositButton = findViewById(R.id.deposit_button);
        withdrawButton = findViewById(R.id.withdraw_button);
        transferButton = findViewById(R.id.transfer_button);
        balanceTextView = findViewById(R.id.balance_text_view);
        receiptButton = findViewById(R.id.receipt_button);
        payBillsButton = findViewById(R.id.pay_bills_button);

        receiptButton.setOnClickListener(v -> printReceipt());
        payBillsButton.setOnClickListener(v -> payBills());

        updateBalanceText();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateBalanceText();
    }

    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("currentBalance", currentBalance);
        editor.apply();
    }

    private void updateBalanceText() {
        balanceTextView.setText(getString(R.string.currentAccBalance, currentBalance));
    }

    public void onDepositButtonClicked(View view) {
        currentBalance += 20;
        updateBalanceText();
        String transactionType = "Deposit: +$20";
        TransactionHistory.addTransaction(this, transactionType, 20);
        Toast.makeText(this, "Deposit successful", Toast.LENGTH_SHORT).show();
    }

    public void onWithdrawButtonClicked(View view) {
        if (currentBalance >= 20) {
            currentBalance -= 20;
            updateBalanceText();
            String transactionType = "Withdrawal: -$20";
            TransactionHistory.addTransaction(this, transactionType, -20);
            Toast.makeText(this, "Withdrawal successful", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Insufficient balance", Toast.LENGTH_SHORT).show();
        }
    }

    public void onTransferButtonClicked(View view) {
        if (currentBalance >= 35) {
            currentBalance -= 35;
            updateBalanceText();
            String transactionType = "Transfer: -$35";
            TransactionHistory.addTransaction(this, transactionType, -35);
            Toast.makeText(this, "Transfer successful", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Insufficient balance", Toast.LENGTH_SHORT).show();
        }
    }

    private void printReceipt() {
        Intent intent = new Intent(this, TransactionActivity.class);
        startActivity(intent);
    }


    private void payBills() {
        int billAmount = 50;
        if (currentBalance >= billAmount) {
            currentBalance -= billAmount;
            updateBalanceText();
            String transactionType = "Bill Payment: -$" + billAmount;
            TransactionHistory.addTransaction(this, transactionType, -billAmount);
            Toast.makeText(this, "Congrats! Your bills are paid", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Insufficient balance to pay your bills", Toast.LENGTH_SHORT).show();
        }
    }
}
