package com.example.banking_app;

import android.content.Context;
import java.util.List;

public class TransactionHistory {

    public static void addTransaction(Context context, String transactionType, int amount) {
        TransactionDbHelper dbHelper = new TransactionDbHelper(context);
        dbHelper.insertTransaction(transactionType, amount);
    }

    public static List<Transaction> getTransactionHistory(Context context) {
        TransactionDbHelper dbHelper = new TransactionDbHelper(context);
        return dbHelper.getTransactionHistory();
    }
}
