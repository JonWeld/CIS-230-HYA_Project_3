package com.example.banking_app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    private EditText passwordInput;
    private Button loginButton;
    private String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        passwordInput = findViewById(R.id.password_input);
        loginButton = findViewById(R.id.login_button);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkPassword();
            }
        });
    }

    private void checkPassword() {
        String enteredPassword = passwordInput.getText().toString();
        if (enteredPassword.equals("Password")) {
            password = enteredPassword;
            showMenu();
        } else {
            Toast.makeText(this, "Invalid password. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    private void showMenu() {
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
    }

    public String getPassword() {
        return password;
    }
}