package com.example.banking_app;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Transaction {
    private int id;
    private String transactionType;
    private int amount;
    private Date timestamp;

    public Transaction(int id, String transactionType, int amount, Date timestamp) {
        this.id = id;
        this.transactionType = transactionType;
        this.amount = amount;
        this.timestamp = timestamp;
    }

    public int getId() {
        return id;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public int getAmount() {
        return amount;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public String getFormattedDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(timestamp);
    }
}
