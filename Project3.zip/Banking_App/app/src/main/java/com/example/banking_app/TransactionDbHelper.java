package com.example.banking_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class TransactionDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "transaction_history.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_TRANSACTIONS = "transactions";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_TRANSACTION_TYPE = "transaction_type";
    public static final String COLUMN_AMOUNT = "amount";
    public static final String COLUMN_TIMESTAMP = "timestamp";
    private static final String SQL_CREATE_TABLE_TRANSACTIONS = "CREATE TABLE " +
            TABLE_TRANSACTIONS + "(" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_TRANSACTION_TYPE + " TEXT NOT NULL, " +
            COLUMN_AMOUNT + " INTEGER NOT NULL, " +
            COLUMN_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP" +
            ")";

    public TransactionDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE_TRANSACTIONS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    public long insertTransaction(String transactionType, int amount) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TRANSACTION_TYPE, transactionType);
        values.put(COLUMN_AMOUNT, amount);
        return db.insert(TABLE_TRANSACTIONS, null, values);
    }

    public List<Transaction> getTransactionHistory() {
        List<Transaction> transactions = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_TRANSACTIONS, null, null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                Transaction transaction = getTransactionFromCursor(cursor);
                transactions.add(transaction);
            }
            cursor.close();
        }

        return transactions;
    }

    private Transaction getTransactionFromCursor(Cursor cursor) {
        int id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID));
        String transactionType = cursor.getString(cursor.getColumnIndex(COLUMN_TRANSACTION_TYPE));
        int amount = cursor.getInt(cursor.getColumnIndex(COLUMN_AMOUNT));
        long timestamp = cursor.getLong(cursor.getColumnIndex(COLUMN_TIMESTAMP));
        Date date = new Date(timestamp);

        return new Transaction(id, transactionType, amount, date);
    }
}
